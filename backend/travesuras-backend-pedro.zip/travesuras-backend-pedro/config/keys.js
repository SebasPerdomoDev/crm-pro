module.exports = {
    secretOrKey: process.env.JWT_SECRET || 'UjXn2r5u8x/A?D(G+KaPdSgVkYp3s6v9y$B&E)H@McQeThWmZq4t7w!z%C*F-JaN'
}